//
//  AngleViewController.swift
//  UnitConverter
//

import UIKit
import Firebase

class AngleViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var degreeTextField : UITextField!
    
    @IBOutlet weak var radTextField : UITextField!
    
   let angleConverter = AngleConverter()
    
   override func viewDidLoad() {
       super.viewDidLoad()
       // Do any additional setup after loading the view, typically from a nib.
       // hide decimal pad
        self.hideKeyboard()
        degreeTextField.resignFirstResponder()
        radTextField.resignFirstResponder()
        self.degreeTextField.delegate = self
        self.radTextField.delegate = self

        fetchAngleValues()
    
   }
    
    

  
   override func didReceiveMemoryWarning() {
       super.didReceiveMemoryWarning()
       // Dispose of any resources that can be recreated.
   }
   
   private func fetchAngleValues() {
        // Retrive Values: -
        let db = Firestore.firestore()
        db.collection("angle").getDocuments { (snapshot, error) in
            if error != nil {
                      print("Error")
                  } else {
                      for document in (snapshot?.documents)! {
                          print(document.data())
                        let array = document.data()
                        let radianValue = array["radian"]
                        let degreeValue = array["degree"]
                        self.radTextField.text = radianValue as? String
                        self.degreeTextField.text = degreeValue as? String
                      }
                  }
            }
    }
    
   @IBAction func degChanged(_ sender: UITextField) {
       let value = sender.text!
       
       if(!value.isEmpty){
           
           let d = Double(value)
        let values = angleConverter.DegToRad(deg: d!)
        radTextField.text = String(values)
       
       }else{
           resetFields()
            
       }
   }
   @IBAction func radChanged(_ sender: UITextField) {
       let value = sender.text!
       
       if(!value.isEmpty){
           
           let d = Double(value)
        let values = angleConverter.radToDeg(rad: d!)
        degreeTextField.text = String(values)
         
       }else{
           resetFields()
       }
   }
    func resetFields(){
        degreeTextField.text = ""
        radTextField.text = ""
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.isEmpty { return true }
        
        let currentText = textField.text ?? ""
        let replacementText = (currentText as NSString).replacingCharacters(in: range, with: string)
        
        return replacementText.isValidDouble(maxDecimalPlaces: 4)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.saveValues()
        return true
    }
    
    private func saveValues() {
        // For Create Values to Store in firestore: -
        let db = Firestore.firestore()
    
        db.collection("angle").addDocument(data: ["degree": degreeTextField.text!, "radian": radTextField.text!]) { (error) in
            if error != nil {
                AlertController.showAlert(self, title: "Not Found", message: error!.localizedDescription)
            }
        }
    }

}
