//
//  Transition.swift
//  FarePriceProduct
//
//  Created by Mohammad Usama on 28/09/2020.
//  Copyright © 2020 apple. All rights reserved.
//

import Foundation

struct Transition {
    
    struct Storyboard {
        
        static let homeVC = "homescreen"
    }
}
